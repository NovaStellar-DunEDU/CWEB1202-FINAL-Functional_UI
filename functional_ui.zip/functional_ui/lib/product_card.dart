import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ProductCard extends StatelessWidget {
  final String BuildName;
  final String BuildDescription;
  final String imageUrl;
  final double price;
  final bool overclocked;

  ProductCard({
    required this.BuildName,
    required this.BuildDescription,
    required this.imageUrl,
    required this.price,
    this.overclocked = false,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape: BeveledRectangleBorder(),
      color: const Color.fromARGB(255, 196, 196, 196),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              height: 216,
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 21, 52, 87),
                border: Border.all(color: Colors.black, width: 2),
              ),
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Image.network(
                      imageUrl,
                      fit: BoxFit.contain,
                    ),
                  ),

                  if (overclocked)
                    Positioned(
                      top: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 0, 102, 255),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Text(
                          "OVERCLOCKED",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),

            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 12),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 148, 176, 236),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    BuildName,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 21, 52, 87),
                    ),
                  ),
                  const SizedBox(width: 6),
                  const Text(
                    "-",
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 21, 52, 87),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    "\$${price.toStringAsFixed(2)}",
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 21, 52, 87),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 12),
              padding: const EdgeInsets.all(12),
              decoration: const BoxDecoration(
                color: Color.fromARGB(255, 148, 176, 236),
              ),
              child: Column(
                children: [
                  Text(
                    BuildDescription,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 11.8,
                      color: Color.fromARGB(255, 21, 52, 87),
                    ),
                  ),


                  const SizedBox(height: 12),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(255, 21, 52, 87),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                            4,
                          ), //
                        ),
                      ),
                      onPressed: () {},
                      child: const Text("> Purchase Me"),
                    ),
                  ),
                ],
              ),
            ),
            
            const SizedBox(height: 12),

          ],
        ),
      ),
    );
  }
}
