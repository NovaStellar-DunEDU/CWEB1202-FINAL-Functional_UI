import 'package:flutter/material.dart';

class DialogBar extends StatelessWidget {
  const DialogBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 180, 205, 255),
              border: Border.all(color: Colors.grey.shade300, width: 10),
            ),
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Color.fromARGB(255, 21, 52, 87),
                      width: 3,
                    ),
                  ),
                  child: ClipRRect(
                    child: Image.network(
                      "assets/images/pcblurb.png",
                      width: 125,
                      height: 120,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),

                const SizedBox(width: 16),

                Expanded(
                  child: Text(
                    "We at PC Doctor strive to usher in the new generation of gamers by offering quality Desktop Builds with the help of our IT Services and support, available to the public for life-long digital sustainability.",
                    style: TextStyle(
                      fontSize: 16,
                      height: 1.4,
                      color: Color.fromARGB(255, 21, 52, 87),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
