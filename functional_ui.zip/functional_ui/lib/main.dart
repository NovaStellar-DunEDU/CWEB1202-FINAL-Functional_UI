import 'dart:html' as html;
import 'package:flutter/material.dart';
import 'package:functional_ui/models/product.dart';
import 'package:functional_ui/product_card.dart';
import 'package:functional_ui/widgets/dialogbar.dart';
import 'dart:ui';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PC Doctor',
      home: const Home(),
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HomePageContent(),
      const Builds(),
    ];

    final titles = [
      "PC Doctor / Home",
      "PC Doctor / Builds",
    ];

    return Scaffold(
      body: Column(
        children: [
          const TopBar(),
          Expanded(child: pages[currentIndex]),
        ],
      ),
      bottomNavigationBar: BottomNavBar(
        onItemSelected: (index) {
          setState(() {
            currentIndex = index;
            html.document.title = titles[index];
          });
        },
      ),
    );
  }
}

class HomePageContent extends StatefulWidget {
  const HomePageContent({super.key});

  @override
  State<HomePageContent> createState() => _HomePageContentState();
}

class _HomePageContentState extends State<HomePageContent> {
  bool hoverClean = false;
  bool hoverFeatured = false;
  bool hoverSupport = false;

  final Color boxBg = const Color.fromARGB(255, 180, 205, 255);
  final Color textDark = const Color.fromARGB(255, 21, 52, 87);
  final Color buttonDark = const Color.fromARGB(255, 21, 52, 87);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            decoration: BoxDecoration(
              color: boxBg,
              border: Border.all(color: Colors.grey.shade300, width: 10),
            ),
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Image.network(
                  "assets/images/homeblurb.png",
                  width: 125,
                  height: 120,
                  fit: BoxFit.cover,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    "We at PC Doctor strive to usher in the new generation of gamers by offering quality Desktop Builds with the help of our IT Services and support, available to the public for life-long digital sustainability.",
                    style: TextStyle(
                      fontSize: 16,
                      height: 1.4,
                      color: textDark,
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          Container(
            decoration: BoxDecoration(
              color: boxBg,
              border: Border.all(color: Colors.grey.shade300, width: 10),
            ),
            padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 20),
            child: Column(
              children: [
                Text(
                  "Electronics Flat-Lined?",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: textDark,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  "Our Certified A+ Technicians are here to help with any and or all of your device problems.",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 16,
                    height: 1.4,
                    color: textDark,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  "Book a full device diagnosis with a free cleaning today!",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: Color.fromARGB(255, 0, 102, 255),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          SizedBox(
            width: double.infinity,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Container(
                    height: 300,
                    decoration: BoxDecoration(
                      color: boxBg,
                      border: Border.all(color: Colors.grey.shade300, width: 10),
                    ),
                    clipBehavior: Clip.hardEdge,
                    child: Image.network(
                      "assets/images/Group 1.png",
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    height: 300,
                    decoration: BoxDecoration(
                      color: boxBg,
                      border: Border.all(color: Colors.grey.shade300, width: 10),
                    ),
                    padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "LIGHT Cleaning Service",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: textDark,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          "Weekdays Available",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 16,
                            color: textDark,
                          ),
                        ),
                        const SizedBox(height: 14),
                        const Text(
                          "\$30.00",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Color.fromARGB(255, 0, 102, 255),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "\$20.00 for customers who previously got a build from us",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 14,
                            height: 1.3,
                            color: textDark,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.star, color: Colors.yellow.shade700, size: 24),
                            Icon(Icons.star, color: Colors.yellow.shade700, size: 24),
                            Icon(Icons.star, color: Colors.yellow.shade700, size: 24),
                            Icon(Icons.star, color: Colors.yellow.shade700, size: 24),
                            Icon(Icons.star, color: Colors.yellow.shade700, size: 24),
                          ],
                        ),
                        const Spacer(),
                        MouseRegion(
                          onEnter: (_) => setState(() => hoverClean = true),
                          onExit: (_) => setState(() => hoverClean = false),
                          child: GestureDetector(
                            onTap: () {},
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              width: double.infinity,
                              height: 45,
                              decoration: BoxDecoration(
                                color: hoverClean
                                    ? const Color.fromARGB(255, 30, 70, 120)
                                    : buttonDark,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Center(
                                child: Icon(Icons.shopping_cart,
                                    color: Colors.white, size: 24),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          SizedBox(
            height: 260,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.network(
                    "assets/images/bytesize_photo (2).png",
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      color: boxBg.withOpacity(0),
                      border: Border.all(color: Colors.grey.shade300, width: 10),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            "Need something that would last you a lifetime?",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: textDark,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "Check out our most popular PC build!",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 15,
                              color: textDark,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "THE COTTON GAUZE V2",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: textDark,
                            ),
                          ),
                          const SizedBox(height: 12),
                          MouseRegion(
                            onEnter: (_) => setState(() => hoverFeatured = true),
                            onExit: (_) => setState(() => hoverFeatured = false),
                            child: GestureDetector(
                              onTap: () {
                                Navigator.pushNamed(context, "/builds");
                              },
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 150),
                                width: 150,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: hoverFeatured
                                      ? const Color.fromARGB(255, 30, 70, 120)
                                      : buttonDark,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: const [
                                    Icon(Icons.shopping_cart,
                                        color: Colors.white, size: 18),
                                    SizedBox(width: 6),
                                    Text(
                                      "Add to Cart",
                                      style: TextStyle(
                                          color: Colors.white, fontSize: 14),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          SizedBox(
            height: 260,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.network(
                    "assets/images/bytesize_photo (3).png",
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      color: boxBg.withOpacity(0),
                      border: Border.all(color: Colors.grey.shade300, width: 10),
                    ),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            "Couldn't find the exact thing you wanted?",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: textDark,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "Fill out a form, or Contact Us in our Support Page.\n"
                            "We are here to help at X:XX to X:XX every day to ensure\n"
                            "customer satisfaction and quality of our services and products.",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 14,
                              height: 1.3,
                              color: textDark,
                            ),
                          ),
                          const SizedBox(height: 12),
                          MouseRegion(
                            onEnter: (_) => setState(() => hoverSupport = true),
                            onExit: (_) => setState(() => hoverSupport = false),
                            child: GestureDetector(
                              onTap: () {},
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 150),
                                width: 150,
                                height: 40,
                                decoration: BoxDecoration(
                                  color: hoverSupport
                                      ? const Color.fromARGB(255, 30, 70, 120)
                                      : buttonDark,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: const Center(
                                  child: Text(
                                    "> Take Me There",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class Builds extends StatelessWidget {
  const Builds({super.key});
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: const DialogBar(),
          ),
          GridView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.all(12),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 0.7,
            ),
            itemCount: products.length,
            itemBuilder: (context, index) {
              final product = products[index];
              return ProductCard(
                BuildName: product.BuildName,
                BuildDescription: product.BuildDescription,
                imageUrl: product.imageUrl,
                price: product.price,
                overclocked: product.overclocked,
              );
            },
          ),
        ],
      ),
    );
  }
}

class TopBar extends StatelessWidget {
  const TopBar({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      color: Colors.grey.shade300,
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 180, 205, 255),
              border: Border.all(color: Colors.grey.shade400, width: 3),
            ),
            child: Text(
              "PCD Logo",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 21, 52, 87),
              ),
            ),
          ),

          const SizedBox(width: 12),

          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              decoration: BoxDecoration(
                color: const Color.fromARGB(255, 180, 205, 255),
                border: Border.all(color: Colors.grey.shade400, width: 3),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Icon(Icons.notifications, size: 26, color: Color.fromARGB(255, 21, 52, 87)),
                  const SizedBox(width: 8),
                  Text(
                    "Notifications",
                    style: TextStyle(
                      fontSize: 18,
                      color: Color.fromARGB(255, 21, 52, 87),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class BottomNavBar extends StatefulWidget {
  final Function(int) onItemSelected;

  const BottomNavBar({super.key, required this.onItemSelected});

  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar>
    with SingleTickerProviderStateMixin {
  int selectedIndex = -1;
  int hoverIndex = -1;

  late AnimationController _controller;
  late Animation<Color?> _colorAnimation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500), // 0.5s fade
    );

    _colorAnimation = ColorTween(
      begin: Colors.lightBlueAccent,
      end: Colors.white,
    ).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 65,
      decoration: const BoxDecoration(
        color: Color.fromARGB(255, 21, 52, 87),
        border: Border(
          top: BorderSide(color: Colors.black, width: 2),
        ),
      ),
      child: Row(
        children: [
          _navItem(Icons.home, 0),
          _navItem(Icons.build, 1),
          _navItem(Icons.shopping_cart, 2),
          _navItem(Icons.person, 3),
        ],
      ),
    );
  }

  Widget _navItem(IconData icon, int index) {
    final bool isHovered = hoverIndex == index;
    final bool isSelected = selectedIndex == index;

    return Expanded(
      child: MouseRegion(
        onEnter: (_) {
          setState(() {
            hoverIndex = index;
          });
        },
        onExit: (_) {
          setState(() {
            hoverIndex = -1;
          });
        },
        child: GestureDetector(
          onTap: () {
            setState(() {
              selectedIndex = index;
            });

            widget.onItemSelected(index);

            // Restart fade animation
            _controller.forward(from: 0).then((_) {
              if (mounted) {
                setState(() {
                  selectedIndex = -1; // clear after fade
                });
              }
            });
          },
          child: Center(
            child: AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                Color iconColor;

                if (isSelected) {
                  iconColor = _colorAnimation.value ?? Colors.white;
                } else if (isHovered) {
                  iconColor = Colors.blue.shade200;
                } else {
                  iconColor = Colors.white;
                }

                return Icon(
                  icon,
                  size: 30,
                  color: iconColor,
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
