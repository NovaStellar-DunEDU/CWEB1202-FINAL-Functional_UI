class Product {
  final String BuildName;
  final String BuildDescription;
  final String imageUrl;
  final double price;
  final bool overclocked;

  Product({
    required this.BuildName,
    required this.BuildDescription,
    required this.imageUrl,
    required this.price,
    this.overclocked = false,
  });
}

final List<Product> products = [
  Product(
    BuildName: "Stethoscope V1",
    BuildDescription: "Ryzen 7 5800X CPU, B550 AM4 ATX Motherboard, 16GB RTX 5060 GPU, 2x8 GB DDR4 RAM, 1TB SSD, 850W",
    imageUrl: "assets/images/image20.png",
    price: 1399.00,
  ),
  Product(
    BuildName: "First Aid Kit V1",
    BuildDescription: "Ryzen 7 9800X3D CPU, B850 AM5 ATX Motherboard, 16GB RTX 5060Ti GPU, 2x16 GB DDR5 RAM, 2TB SSD, 850W",
    imageUrl: "assets/images/image21.png",
    price: 1899.00,
  ),
  Product(
    BuildName: "Bandage Wrap V1",
    BuildDescription: "Ryzen 5 5500 CPU, B550 AM4 ATX Motherboard, 8GB RTX 4060 GPU, 2x8 GB DDR4 RAM, 1TB SSD, 850W",
    imageUrl: "assets/images/image23.png",
    price: 1000.00,
  ),
  Product(
    BuildName: "Cotton Gauze V2",
    BuildDescription: "Ryzen 5 5500 CPU, B550 AM4 ATX Motherboard, 12GB RTX 3060 GPU, 2x8 GB DDR4 RAM, 1TB SSD, 850W",
    imageUrl: "assets/images/image24.png",
    price: 920.00,
  ),
    Product(
    BuildName: "Cotton Gauze V1",
    BuildDescription: "Ryzen 5 3600 CPU, A520I AM4 M-ITX Motherboard, 8GB RTX 3050 GPU, 1x8 GB DDR4 RAM, 1TB SSD, 650W",
    imageUrl: "assets/images/Group.png",
    price: 739.00,
  ),
  Product(
    BuildName: "Centrifuge V1",
    BuildDescription: "Ryzen 7 9800X3D CPU, B850-I AM5 M-ITX Motherboard, 12GB RTX 3060 GPU, 2x8 GB DDR5 RAM, 1TB SSD, 850W",
    imageUrl: "assets/images/image26.png",
    price: 1699.00,
  ),
  Product(
    BuildName: "Test Tube V1",
    BuildDescription: "Ryzen 5 3600 CPU, B550-I AM4 M-ITX Motherboard, 6GB RTX 3050 GPU, 2x8 GB DDR4 RAM, 1TB SSD, 750W",
    imageUrl: "assets/images/bytesize_photo.png",
    price: 899.00,
  ),
  Product(
    BuildName: "Cryosleep V1",
    BuildDescription: "Ryzen 7 9800X3D CPU, B550 AM5 ATX Motherboard, 16GB RTX 5070Ti GPU, 2x16 GB DDR5 RAM, 2TB SSD, 1000W",
    imageUrl: "assets/images/image28.png",
    price: 2599.00,
  ),
  Product(
    BuildName: "Defibulator V1",
    BuildDescription: "Ryzen 7 9800X3D CPU, B550 AM5 ATX Motherboard, 16GB RTX 5090 GPU, 2x16 GB DDR5 RAM, 2TB SSD, 1000W",
    imageUrl: "assets/images/image29.png",
    price: 4599.00,
  ),
  Product(
    BuildName: "Centrifuge V2",
    BuildDescription: "Ryzen 7 9800X3D CPU, B850-I AM5 M-ITX Motherboard, 16GB RTX 5070Ti OC GPU, 2x16 GB DDR5 OC RAM, 2TB SSD, 1000W",
    imageUrl: "assets/images/image26.png",
    price: 2799.00,
    overclocked: true,
  ),
  Product(
    BuildName: "First Aid Kit V2",
    BuildDescription: "Ryzen 7 9800X3D CPU, B850 AM5 ATX Motherboard, 16GB RTX 5070Ti OC GPU, 2x16 GB DDR5 OC RAM, 2TB SSD, 1000W",
    imageUrl: "assets/images/image26.png",
    price: 2499.00,
    overclocked: true,
  ),
    Product(
    BuildName: "Stethoscope V2",
    BuildDescription: "Ryzen 7 5800X CPU, B550 AM4 ATX Motherboard, 16GB RTX 5070Ti OC GPU, 2x16 GB DDR4 RAM, 1TB SSD, 1000W",
    imageUrl: "assets/images/image26.png",
    price: 1899.00,
    overclocked: true,
  ),
];
